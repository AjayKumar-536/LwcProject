import { LightningElement, api } from 'lwc';

export default class BirthdaySurprise extends LightningElement {
    @api recipientName = 'Someone Special';
    @api senderName = 'Your Name';
    @api birthdayMessage = 'You make the world brighter just by being in it. I hope your birthday brings you as much happiness as you bring to everyone around you. Keep smiling, keep shining, and may all your dreams come true. Happy Birthday!';
    @api videoUrl = '';

    isMessageVisible = false;

    get buttonLabel() {
        return this.isMessageVisible ? 'Your surprise is open 💝' : 'Open your birthday surprise 💌';
    }

    get hasVideo() {
        return Boolean(this.videoUrl && this.videoUrl.trim());
    }

    revealMessage() {
        this.isMessageVisible = true;
    }
}
